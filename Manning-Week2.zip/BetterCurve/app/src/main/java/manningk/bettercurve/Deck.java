package manningk.bettercurve;

/**
 * Created by Kevin on 1/16/2016.
 */
public class Deck
{
}
